#!/bin/bash
C programming
