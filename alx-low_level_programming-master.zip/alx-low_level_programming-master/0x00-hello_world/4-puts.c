#include <stdio.h>

/**
 * main - 0 entry point
 *
 * Return: 0
 */
int main(void)
{
	puts("\"Programming is like building a multilingual puzzle");
	return (0);
}
