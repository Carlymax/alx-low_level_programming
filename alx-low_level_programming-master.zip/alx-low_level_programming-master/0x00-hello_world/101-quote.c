#include <stdio.h>
/**
 * main - entry point
 *
 * Return: 0 (Success)
 *
 */
int main(void)
{
	puts("and that piece of art is useful\" - Dora Korpar, 2015-10-19");
	return (1);
}
