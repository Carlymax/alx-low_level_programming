##0x01. C - Variables, if, else, while
0. This program will assign a random number to the variable n each time it is executed. Complete the source code in order to print whether the number stored in the variable n is positive or negative.

1. This program will assign a random number to the variable n each time it is executed. Complete the source code in order to print the last digit of the number stored in the variable n.


2. Write a program that prints the alphabet in lowercase, followed by a new line.You can only use the putchar function (every other function (printf, puts, etc…) is forbidden)
All your code should be in the main function
You can only use putchar twice in your code

3. Write a program that prints the alphabet in lowercase, followed by a new line.

4. Write a program that prints the alphabet in lowercase, followed by a new line.


