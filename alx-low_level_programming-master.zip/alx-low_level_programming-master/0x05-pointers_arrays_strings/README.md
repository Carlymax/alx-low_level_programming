## 0x05. C - Pointers, arrays and strings

0. 98 Battery st.
   Write a function that takes a pointer to an int as parameter and updates the value it points to to 98
1. Don't swap horses in crossing a stream

2. This report, by its very length, defends itself against the risk of being read

3. I do not fear computers. I fear the lack of them
