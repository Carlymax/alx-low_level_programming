#include "main.h"
#include <stdio.h>

/**
 * reset_to_98 - update value of int to 98
 * @n: integer
 */
void reset_to_98(int *n)
{
	*n = 98;
}

