#include <stdio.h>

/**
 * main - printing address of a pointer
 *
 * Return: Always 0
 */
int main(void)
{
	int *p;

	printf("Address of variable 'p': %p\n", &p);
	return (0);
}
