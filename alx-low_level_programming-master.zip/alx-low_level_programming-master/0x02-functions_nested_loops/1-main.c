#include "main.h"

/**
 * main - calls other functions
 *
 * Return: 0
 */
int main(void)
{
	print_alphabet();
	return (0);
}

