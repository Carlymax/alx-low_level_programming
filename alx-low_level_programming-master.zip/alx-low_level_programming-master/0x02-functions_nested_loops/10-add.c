#include "main.h"

/**
 * add - adds 2 integers and returns result
 * @a: first integer
 * @b: second integer
 * Return: a + b
 */
int add(int a, int b)
{
	return (a + b);
}
