#include "main.h"
/**
 * main - check the code
 * Return: 0 always
 */
int main(void)
{
	times_table();
	return (0);
}
