#include <stdio.h>
#include "main.h"

/**
 * main - checks the code
 *
 * Return: Always 0
 *
 */
int main(void)
{
	int n;

	n = add(89, 9);
	printf("%d\n", n);
	return (0);
}
