#include "main.h"

/**
 * times_table - prints 9 times table starting with 0
 *
 * Return: 0(Success)
 *
 */
void times_table(void)
{

