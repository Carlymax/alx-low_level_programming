#0x02. C - Functions, nested loops
0. Write a program that prints _putchar, followed by a new line.

1. Write a function that prints the alphabet, in lowercase, followed by a new line.

2. Write a function that prints 10 times the alphabet, in lowercase, followed by a new line.

3. Write a function that checks for lowercase character.

4. Write a function that checks for alphabetic character.

5. Write a function that prints the sign of a number.

6. Write a function that computes the absolute value of an integer.

7. Write a function that prints the last digit of a number.

8. Write a function that prints every minute of the day of Jack Bauer, starting from 00:00 to 23:59.

9. Write a function that prints the 9 times table, starting with 0.

10. Write a function that adds two integers and returns the result.

11. Write a function that prints all natural numbers from n to 98, followed by a new line.
