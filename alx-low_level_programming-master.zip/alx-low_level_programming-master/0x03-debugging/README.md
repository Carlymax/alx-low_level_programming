#0x03. C - Debugging
0. Multiple mains

1. Like, comment, subscribe

2. 0 > 972?
