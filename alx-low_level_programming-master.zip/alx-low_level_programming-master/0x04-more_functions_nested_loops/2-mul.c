#include "main.h"

/**
 * mul - multiplies 2 integers
 * @a: 1st integer
 * @b: 2nd integer
 * Return: a * b
 */
int mul(int a, int b)
{
	return (a * b);
}

