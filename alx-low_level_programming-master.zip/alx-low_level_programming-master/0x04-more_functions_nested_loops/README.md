## 0x04. C - More functions, more nested loops

0. isupper

1. isdigit

2. Collaboration is multiplication

3. The numbers speak for themselves

