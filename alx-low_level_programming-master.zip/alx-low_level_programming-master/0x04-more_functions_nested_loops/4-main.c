#include "main.h"
#include <stdio.h>
/**
 * main - check the code
 *
 * Return: 0 Always
 *
 */
int main(void)
{
	print_most_numbers();
	return (0);
}
