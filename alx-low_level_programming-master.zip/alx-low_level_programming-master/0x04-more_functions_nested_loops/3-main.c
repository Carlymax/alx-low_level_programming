#include "main.h"

/**
 * main - check the code
 *
 * Return: 0
 */
int main(void)
{
	print_numbers();
	return (0);
}
